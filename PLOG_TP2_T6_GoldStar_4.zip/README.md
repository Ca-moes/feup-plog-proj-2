# Intruções de execução
## Windows
- Executar `spwin.exe`
- `File` -> `Consult...` -> Selecionar ficheiro `goldstar.pl`
- Na consola do SicStus: `start.`
## Linux
- Executar `SicStus Prolog`
- `File` -> `Consult...` -> Selecionar ficheiro `goldstar.pl`
- Na consola do SicStus: `start.`

---

```prolog
Main Menu

1 - Input Operators
2 - Show Solver
3 - Find Solution (Random Config)
4 - DevOps - Save Results
5 - DevOps - Save Heuristics Solver
6 - DevOps - Save Heuristics Ops
0 - Exit
| Choose an Option (0-6) - 
```


As opções 1,2,3 mostram os resultados na consola enquanto que as opções 4,5,6 guardam os resultados em ficheiros de texto no "Working Directory" definido.